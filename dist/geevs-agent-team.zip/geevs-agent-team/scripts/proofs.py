"""Deterministic proofs for a review: test-first for code, source-traced claims for documents."""

import ast
import decimal
import operator
import pathlib
import re
import subprocess
import tempfile

CODE_SUFFIXES = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".go",
    ".rs",
    ".java",
    ".kt",
    ".rb",
    ".php",
    ".cs",
    ".swift",
    ".c",
    ".cc",
    ".cpp",
    ".h",
    ".sql",
    ".sh",
}
DOC_SUFFIXES = {".md", ".txt", ".rst", ".html", ".csv"}
TEST_PATH = re.compile(r"(^|/)(tests?|__tests__)/|(^|/)test_[^/]+$|_test\.[a-z]+$|\.(test|spec)\.[a-z]+$")
NUMBER = re.compile(r"\d[\d,]*(?:\.\d+)?")
LIST_ORDINAL = re.compile(r"^\s*\d+[.)]\s", re.M)
CITATION = re.compile(r"\bline \d+\b|\S+\.(md|txt|rst|html|csv|py)\b", re.I)
PERCENT_BASE = "100"
OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}


def git(path, *args, check=True):
    out = subprocess.run(["git", "-C", str(path), *args], capture_output=True, text=True, check=False, timeout=60)
    if check and out.returncode != 0:
        raise RuntimeError(out.stderr.strip() or f"git {' '.join(args)} failed")
    return out.stdout.strip()


def default_branch(path):
    for name in ("main", "master"):
        if git(path, "rev-parse", "--verify", "--quiet", name, check=False):
            return name
    raise RuntimeError("no main or master branch to compare against")


def changed_files(path):
    """Base commit, head commit and files changed on the branch since it left the default branch."""
    head = git(path, "rev-parse", "HEAD")
    base = git(path, "merge-base", head, default_branch(path))
    files = [f for f in git(path, "diff", "--name-only", base, head).splitlines() if f]
    return base, head, files


def needs(files):
    """Which proofs a set of changed files requires."""
    suffixes = {pathlib.PurePosixPath(f).suffix.lower() for f in files}
    return {"code": bool(suffixes & CODE_SUFFIXES), "docs": bool(suffixes & DOC_SUFFIXES)}


def run(command, cwd):
    return subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=False, timeout=600).returncode


def red_green(path, command):
    """New tests must fail on the base code and pass on the branch."""
    base, head, files = changed_files(path)
    tests = [f for f in files if TEST_PATH.search(f)]
    if not tests:
        return {"ok": False, "head": head, "reason": "no test files changed on the branch"}
    with tempfile.TemporaryDirectory() as tmp:
        scratch = pathlib.Path(tmp) / "base"
        git(path, "worktree", "add", "--detach", str(scratch), base)
        try:
            git(scratch, "checkout", head, "--", *tests)
            red = run(command, scratch)
        finally:
            git(path, "worktree", "remove", "--force", str(scratch), check=False)
    green = run(command, path)
    ok = red != 0 and green == 0
    result = {"ok": ok, "head": head, "base": base, "tests": tests, "red_exit": red, "green_exit": green}
    if not ok:
        result["reason"] = "new tests pass on the base code" if red == 0 else "tests fail on the branch"
    return result


def normalise(text):
    return " ".join(text.replace(",", "").split())


def numbers(text):
    """Numbers as written, commas removed, so 1.0 (a rate) and 1.00 (a fee) stay distinct."""
    return {n.replace(",", "") for n in NUMBER.findall(CITATION.sub("", text or ""))}


def evaluate(node):
    """Exact arithmetic over + - * /, round half-up, max, min and numeric literals only."""
    if isinstance(node, ast.Expression):
        return evaluate(node.body)
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and not node.keywords:
        return call(node.func.id, node.args)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return decimal.Decimal(str(node.value))
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        return OPS[type(node.op)](evaluate(node.left), evaluate(node.right))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -evaluate(node.operand)
    raise ValueError("only numbers and + - * / are allowed")


def call(name, args):
    if name == "round" and len(args) == 2 and isinstance(args[1], ast.Constant) and type(args[1].value) is int:
        step = decimal.Decimal(1).scaleb(-args[1].value)
        return evaluate(args[0]).quantize(step, rounding=decimal.ROUND_HALF_UP)
    if name in ("max", "min") and len(args) >= 2:
        return (max if name == "max" else min)(evaluate(a) for a in args)
    raise ValueError("only round(x, digits), max and min are allowed")


def round_digits(calc):
    """Digit counts in round() calls, which are not figures needing a source."""
    try:
        tree = ast.parse(calc, mode="eval")
    except SyntaxError:
        return set()
    return {
        str(n.args[1].value)
        for n in ast.walk(tree)
        if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "round" and len(n.args) == 2
        and isinstance(n.args[1], ast.Constant)
    }


def as_list(value):
    if value is None:
        return []
    return [str(v) for v in value] if isinstance(value, list) else [str(value)]


def support_problems(i, claim):
    """Numbers in a claim must be quoted, declared as given inputs, or the result of its calc."""
    allowed = numbers(" ".join(as_list(claim.get("quote")))) | numbers(" ".join(as_list(claim.get("given"))))
    unsupported = numbers(claim.get("claim")) - allowed
    if not unsupported:
        return []
    if not claim.get("calc"):
        return [f"claim {i}: {', '.join(map(str, sorted(unsupported)))} not in the quote and no calc given"]
    try:
        result = evaluate(ast.parse(str(claim["calc"]), mode="eval"))
    except (SyntaxError, ValueError, ArithmeticError) as error:
        return [f"claim {i}: calc not valid: {error}"]
    problems = [
        f"claim {i}: calc uses {n}, which is not quoted or given"
        for n in numbers(str(claim["calc"])) - allowed - {PERCENT_BASE} - round_digits(str(claim["calc"]))
    ]
    problems += [
        f"claim {i}: {n} does not match calc result {result}"
        for n in sorted(unsupported)
        if decimal.Decimal(n) != result
    ]
    return problems


def claim_problems(path, claims):
    problems = []
    for i, claim in enumerate(claims, 1):
        target = pathlib.Path(path) / claim.get("file", "")
        source = pathlib.Path(path) / claim.get("source", "").split(":")[0]
        if not target.is_file() or normalise(claim.get("claim", "")) not in normalise(target.read_text()):
            problems.append(f"claim {i}: text not found in {claim.get('file')}")
        cited = normalise(source_text(source, claim)) if source.is_file() else None
        quotes = as_list(claim.get("quote")) or [""]
        if cited is None or any(normalise(q) not in cited for q in quotes):
            problems.append(f"claim {i}: quote not found at {claim.get('source')}")
        problems += support_problems(i, claim)
    return problems


def source_text(source, claim):
    """The cited lines when the source is file:line[,line], otherwise the whole file."""
    lines = source.read_text().splitlines()
    _, _, cited = claim.get("source", "").partition(":")
    if not cited:
        return "\n".join(lines)
    picked = [lines[int(n) - 1] for n in cited.split(",") if n.strip().isdigit() and 0 < int(n) <= len(lines)]
    return "\n".join(picked) if len(picked) == len(cited.split(",")) else ""


def uncovered_numbers(path, claims):
    covered = {n.replace(",", "") for c in claims for n in NUMBER.findall(c.get("claim", ""))}
    files = {c.get("file") for c in claims if c.get("file")}
    missing = set()
    for name in files:
        target = pathlib.Path(path) / name
        if target.is_file():
            text = LIST_ORDINAL.sub("", target.read_text())
            missing |= {n.replace(",", "") for n in NUMBER.findall(text)} - covered
    return sorted(missing)


def traced(path, claims):
    """Every claim appears in its document, every quote in its source, every number in some claim."""
    head = git(path, "rev-parse", "HEAD")
    if not claims:
        return {"ok": False, "head": head, "reason": "no claims listed"}
    problems = claim_problems(path, claims)
    problems += [f"number {n} has no sourced claim" for n in uncovered_numbers(path, claims)]
    return {"ok": not problems, "head": head, "claims": len(claims), "problems": problems}
